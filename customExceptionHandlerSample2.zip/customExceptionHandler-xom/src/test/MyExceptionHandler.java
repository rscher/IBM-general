package test;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ibm.rules.engine.ruledef.runtime.CustomExceptionHandler;
import com.ibm.rules.engine.ruledef.runtime.RuleInstance;

public class MyExceptionHandler implements CustomExceptionHandler {

	Logger logger = Logger.getLogger(MyExceptionHandler.class.getName());
	static ArrayList<String> errors = null;

	public static void setErrors(ArrayList<String> errors) {
		MyExceptionHandler.errors = errors;
	}

	private static void addError(String err) {
		if (null != errors) {
			errors.add(err);
		}		
	}
	
	/**
	  * The custom exception handler must contain a default constructor.
	  */
	public MyExceptionHandler() {
	}

	@Override
	public void handleConditionException(Exception e) throws Exception 
	{
		if (logger.isLoggable(Level.INFO)) {
			logger.log(Level.INFO, "Exception while executing a condition in a rule", e);
		}
		addError(e.getClass().getName() + " while executing condition of a rule ");

		if (e instanceof NumberFormatException) {
			// ignore number format exception
		} else {
			// rethrow the exception, it will stop the engine execution
			throw e;
		}
	  }

	  @Override
	  public void handleActionException(Exception e, RuleInstance ruleInstance) throws Exception
	  {
		  String err = e.getClass().getName() + " while executing action of rule " + ruleInstance.getRuleName();
	      if (logger.isLoggable(Level.INFO)) {
	    	  logger.log(Level.INFO, err, e);
	      }

		  if (null != errors) {
			  addError(err);
		  }
	  }
}
